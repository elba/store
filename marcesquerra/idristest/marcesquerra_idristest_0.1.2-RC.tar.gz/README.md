Simple testing library for Idris
